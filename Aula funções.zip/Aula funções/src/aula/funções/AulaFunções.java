/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula.funções;

import javax.swing.JOptionPane;

/**
 *
 * @author rafael.psilva70
 */
public class AulaFunções {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        JOptionPane.showMessageDialog(null,"Syntax.error");
        JOptionPane.showMessageDialog(null, "You're special");
    }
    
}
