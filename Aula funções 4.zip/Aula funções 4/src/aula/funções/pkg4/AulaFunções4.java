/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula.funções.pkg4;

import javax.swing.JOptionPane;

/**
 *
 * @author rafael.psilva70
 */
public class AulaFunções4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //JOptionPane.showMessageDialog(null,"Seja bem-vindo");
        //JOptionPane.showInputDialog(null,"Insira seu nome");
        //JOptionPane.showConfirmDialog(null,"Está correto?");
        
        
        String nome = JOptionPane.showInputDialog(null,"Insira seu nome");
        JOptionPane.showMessageDialog(null,"Bem vindo " + nome + "!");
        
        String CPF = JOptionPane.showInputDialog(null,"Insira seu CPF: ");
        JOptionPane.showConfirmDialog(null,"Seu CPF é: " + CPF + "?");
        JOptionPane.showMessageDialog(null,"Muito bem, você é um pescador de respeito!");
    }
    
}
